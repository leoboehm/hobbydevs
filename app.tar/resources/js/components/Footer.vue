<template>
    <v-footer app>
        <v-row dense class="text-center">
            <v-spacer />
            <span>2025 HobbyDevs. All rights reserved.</span>
            <v-spacer />
        </v-row>
    </v-footer>
</template>

<script setup></script>

<style scoped>
v-footer {
    background-color: #333;
    color: white;
}
</style>

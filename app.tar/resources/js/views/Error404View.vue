<template>
    <v-container
        class="fill-height text-center d-flex flex-column justify-center align-center"
    >
        <v-icon size="128" color="error">mdi-alert-octagon</v-icon>
        <h1 class="text-h3 font-weight-bold mt-4">404 - Page Not Found</h1>
        <p class="text-subtitle-1">
            Oops! The page you’re looking for doesn’t exist.
        </p>
        <v-btn color="primary" class="mt-4" to="/"> Go Back Home </v-btn>
    </v-container>
</template>

<script setup></script>
